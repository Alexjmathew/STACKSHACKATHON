export type SipData = {
  amount: bigint;
  active: boolean;
};
