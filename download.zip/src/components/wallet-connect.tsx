"use client";

import { useEffect, useState } from "react";
import { showConnect } from "@stacks/connect";
import { userSession } from "@/lib/stacks";
import { toStx } from "@/lib/utils";
import { APP_NAME, APP_ICON } from "@/lib/constants";

import { Button } from "@/components/ui/button";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { Wallet, LogOut, Loader2 } from "lucide-react";

export default function WalletConnect() {
  const [balance, setBalance] = useState<string | null>(null);
  const [loading, setLoading] = useState(true);
  const [iconUrl, setIconUrl] = useState('');
  const [isConnected, setIsConnected] = useState(false);

  useEffect(() => {
    if (typeof window !== 'undefined') {
      setIconUrl(`${window.location.origin}${APP_ICON}`);
    }
    setIsConnected(userSession.isUserSignedIn());
    setLoading(false);
  }, []);

  const stxAddress = userSession.isUserSignedIn() ? userSession.loadUserData().profile.stxAddress.mainnet : undefined;

  const getAvatarFallback = () => {
    if (!stxAddress) return "U";
    return stxAddress.substring(0, 2).toUpperCase();
  };

  const getDisplayAddress = () => {
    if (!stxAddress) return "";
    return `${stxAddress.substring(0, 5)}...${stxAddress.substring(stxAddress.length - 5)}`;
  };

  const handleConnect = () => {
    if (!iconUrl) return;
    showConnect({
      appDetails: {
        name: APP_NAME,
        icon: iconUrl,
      },
      userSession,
      onFinish: () => {
        window.location.reload();
      },
      onCancel: () => {
        console.log('User cancelled connection');
      }
    });
  }

  const handleDisconnect = () => {
    userSession.signUserOut();
    window.location.reload();
  }
  
  if (loading || !iconUrl) {
    return <Button variant="outline" size="icon" disabled><Loader2 className="h-4 w-4 animate-spin" /></Button>
  }

  if (isConnected) {
    return (
      <DropdownMenu>
        <DropdownMenuTrigger asChild>
          <Button variant="outline" className="pl-2">
            <Avatar className="h-7 w-7 mr-2">
              <AvatarFallback>{getAvatarFallback()}</AvatarFallback>
            </Avatar>
            <span>{getDisplayAddress()}</span>
          </Button>
        </DropdownMenuTrigger>
        <DropdownMenuContent align="end">
          <DropdownMenuLabel>My Account</DropdownMenuLabel>
          <DropdownMenuSeparator />
          <DropdownMenuItem onClick={handleDisconnect}>
            <LogOut className="mr-2 h-4 w-4" />
            <span>Log out</span>
          </DropdownMenuItem>
        </DropdownMenuContent>
      </DropdownMenu>
    );
  }

  return (
    <Button onClick={handleConnect}>
      <Wallet className="mr-2 h-4 w-4" />
      Connect Wallet
    </Button>
  );
}
