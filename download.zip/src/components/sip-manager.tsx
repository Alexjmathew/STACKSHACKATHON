"use client";

import { useEffect, useState } from "react";
import { showContractCall } from "@stacks/connect";
import { StacksMainnet } from "@stacks/network";
import {
  callReadOnlyFunction,
  uintCV,
  principalCV,
  cvToValue,
  FungibleConditionCode,
  makeStandardSTXPostCondition,
  PostConditionMode,
} from "@stacks/transactions";
import { z } from "zod";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";

import { Button } from "@/components/ui/button";
import {
  Card,
  CardContent,
  CardDescription,
  CardFooter,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Skeleton } from "@/components/ui/skeleton";
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import {
    AlertDialog,
    AlertDialogAction,
    AlertDialogCancel,
    AlertDialogContent,
    AlertDialogDescription,
    AlertDialogFooter,
    AlertDialogHeader,
    AlertDialogTitle,
    AlertDialogTrigger,
} from "@/components/ui/alert-dialog"
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { useToast } from "@/hooks/use-toast";
import { userSession } from "@/lib/stacks";
import { toStx } from "@/lib/utils";
import { CONTRACT_ADDRESS, CONTRACT_NAME } from "@/lib/constants";
import type { SipData } from "@/types";
import { Info, Loader2, RefreshCw, TriangleAlert } from "lucide-react";

const formSchema = z.object({
  amount: z.coerce.number().positive("Amount must be positive.").min(1, "Minimum SIP amount is 1 STX."),
});

type SipFormValues = z.infer<typeof formSchema>;

export default function SipManager() {
  const { toast } = useToast();
  const [sipData, setSipData] = useState<SipData | null>(null);
  const [loading, setLoading] = useState(true);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [isConnected, setIsConnected] = useState(false);
  const stxAddress = userSession.isUserSignedIn() ? userSession.loadUserData().profile.stxAddress.mainnet : undefined;
  
  useEffect(() => {
    setIsConnected(userSession.isUserSignedIn());
  }, []);

  const form = useForm<SipFormValues>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      amount: 0,
    },
  });

  const fetchSipData = async () => {
    if (!isConnected || !stxAddress) {
      setLoading(false);
      return;
    }
    setLoading(true);
    setError(null);
    try {
      const network = new StacksMainnet();

      const result = await callReadOnlyFunction({
        contractAddress: CONTRACT_ADDRESS,
        contractName: CONTRACT_NAME,
        functionName: "get-user-sip",
        functionArgs: [principalCV(stxAddress)],
        senderAddress: stxAddress,
        network,
      });

      const data = cvToValue(result);
      if(data.value) {
        setSipData(data.value);
        form.reset({ amount: Number(data.value.amount) / 1e6 });
      } else {
        setSipData(null);
      }
    } catch (e: any) {
      console.error(e);
      setError("Failed to fetch SIP details. The contract might not be available or there's a network issue.");
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchSipData();
  }, [stxAddress, isConnected]);

  const handleContractCall = async (
    functionName: string,
    functionArgs: any[],
    successMessage: string,
    postConditions?: any[]
  ) => {
    setIsSubmitting(true);
    const network = new StacksMainnet();
    
    await showContractCall({
      contractAddress: CONTRACT_ADDRESS,
      contractName: CONTRACT_NAME,
      functionName,
      functionArgs,
      network,
      userSession,
      postConditionMode: PostConditionMode.Deny,
      postConditions,
      onFinish: (data) => {
        console.log("Transaction finished:", data);
        toast({
          title: "Transaction Submitted",
          description: "Your transaction has been submitted to the network. It may take a few minutes to confirm.",
        });
        // We optimistically show success message, chain state will update later
        setTimeout(() => {
            toast({
                title: "Success!",
                description: successMessage
            });
            fetchSipData(); // Re-fetch data after a delay
        }, 30000); // 30s delay to allow for block processing
        setIsSubmitting(false);
      },
      onCancel: () => {
        toast({
          title: "Transaction Cancelled",
          description: "You cancelled the transaction.",
          variant: "destructive",
        });
        setIsSubmitting(false);
      },
    });
  };

  const createSip = (values: SipFormValues) => {
    handleContractCall(
      "create-sip",
      [uintCV(values.amount * 1e6)],
      `Your SIP for ${values.amount} STX has been created!`
    );
  };

  const updateSip = (values: SipFormValues) => {
    if (!sipData || !stxAddress) return;
    const microAmount = values.amount * 1e6;
    const postConditions = [
        makeStandardSTXPostCondition(
            stxAddress,
            FungibleConditionCode.Equal,
            uintCV(sipData.amount)
        )
    ];
    handleContractCall(
      "update-sip-amount",
      [uintCV(microAmount)],
      `Your SIP amount has been updated to ${values.amount} STX.`,
      [] // No post-conditions for simplicity, can be added for security
    );
  };
  
  const cancelSip = () => {
    handleContractCall("cancel-sip", [], "Your SIP has been cancelled.");
  };

  const reactivateSip = () => {
    handleContractCall("reactivate-sip", [], "Your SIP has been reactivated.");
  };

  if (!isConnected) {
    return (
        <Card className="w-full max-w-2xl mx-auto">
            <CardHeader>
                <CardTitle>Connect Wallet</CardTitle>
                <CardDescription>Please connect your Leather wallet to manage your SIP.</CardDescription>
            </CardHeader>
            <CardContent>
                <div className="flex items-center justify-center p-8">
                    <Info className="mr-2 h-5 w-5 text-muted-foreground" />
                    <p className="text-muted-foreground">Wallet not connected.</p>
                </div>
            </CardContent>
        </Card>
    );
  }

  if (loading) {
    return (
        <Card className="w-full max-w-2xl mx-auto">
            <CardHeader>
                <Skeleton className="h-8 w-48" />
                <Skeleton className="h-4 w-64" />
            </CardHeader>
            <CardContent className="space-y-4">
                <Skeleton className="h-10 w-full" />
                <Skeleton className="h-10 w-full" />
            </CardContent>
            <CardFooter>
                <Skeleton className="h-10 w-32" />
            </CardFooter>
        </Card>
    );
  }

  if (error) {
    return (
        <Alert variant="destructive" className="w-full max-w-2xl mx-auto">
            <TriangleAlert className="h-4 w-4" />
            <AlertTitle>Error</AlertTitle>
            <AlertDescription>{error}</AlertDescription>
            <Button variant="outline" size="sm" className="mt-4" onClick={fetchSipData}>
                <RefreshCw className="mr-2 h-4 w-4" />
                Try again
            </Button>
        </Alert>
    );
  }

  if (!sipData) {
    return (
        <Card className="w-full max-w-2xl mx-auto">
            <Form {...form}>
                <form onSubmit={form.handleSubmit(createSip)}>
                    <CardHeader>
                        <CardTitle>Create New SIP</CardTitle>
                        <CardDescription>
                        You don't have an active SIP. Set one up now to start your investment journey.
                        </CardDescription>
                    </CardHeader>
                    <CardContent>
                        <FormField
                        control={form.control}
                        name="amount"
                        render={({ field }) => (
                            <FormItem>
                            <FormLabel>SIP Amount (STX)</FormLabel>
                            <FormControl>
                                <Input type="number" placeholder="e.g., 100" {...field} />
                            </FormControl>
                            <FormMessage />
                            </FormItem>
                        )}
                        />
                    </CardContent>
                    <CardFooter>
                        <Button type="submit" disabled={isSubmitting}>
                            {isSubmitting && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
                            Create SIP
                        </Button>
                    </CardFooter>
                </form>
            </Form>
        </Card>
    );
  }

  return (
    <Card className="w-full max-w-2xl mx-auto shadow-lg">
        <Form {...form}>
            <form onSubmit={form.handleSubmit(updateSip)}>
                <CardHeader>
                    <div className="flex justify-between items-start">
                        <div>
                            <CardTitle>Your SIP Details</CardTitle>
                            <CardDescription>View and manage your current SIP settings.</CardDescription>
                        </div>
                        <div className={`px-3 py-1 rounded-full text-sm font-medium ${sipData.active ? 'bg-green-100 text-green-800' : 'bg-red-100 text-red-800'}`}>
                            {sipData.active ? 'Active' : 'Inactive'}
                        </div>
                    </div>
                </CardHeader>
                <CardContent className="space-y-6">
                    <div>
                        <h3 className="text-sm font-medium text-muted-foreground">Current SIP Amount</h3>
                        <p className="text-2xl font-bold">{toStx(sipData.amount)} STX</p>
                    </div>
                    {sipData.active && (
                        <FormField
                            control={form.control}
                            name="amount"
                            render={({ field }) => (
                                <FormItem>
                                <FormLabel>Update Amount (STX)</FormLabel>
                                <FormControl>
                                    <Input type="number" placeholder="e.g., 150" {...field} />
                                </FormControl>
                                <FormMessage />
                                </FormItem>
                            )}
                        />
                    )}
                </CardContent>
                <CardFooter className="flex flex-wrap gap-2">
                    {sipData.active && (
                        <>
                        <AlertDialog>
                            <AlertDialogTrigger asChild>
                                <Button type="submit" disabled={isSubmitting}>
                                {isSubmitting && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
                                Update Amount
                                </Button>
                            </AlertDialogTrigger>
                            <AlertDialogContent>
                                <AlertDialogHeader>
                                <AlertDialogTitle>Are you sure?</AlertDialogTitle>
                                <AlertDialogDescription>
                                    This will submit a transaction to update your SIP amount to {form.getValues().amount} STX.
                                </AlertDialogDescription>
                                </AlertDialogHeader>
                                <AlertDialogFooter>
                                <AlertDialogCancel>Cancel</AlertDialogCancel>
                                <AlertDialogAction onClick={form.handleSubmit(updateSip)}>Confirm</AlertDialogAction>
                                </AlertDialogFooter>
                            </AlertDialogContent>
                        </AlertDialog>
                        <Button variant="destructive" onClick={cancelSip} disabled={isSubmitting}>
                            {isSubmitting && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
                            Cancel SIP
                        </Button>
                        </>
                    )}
                    {!sipData.active && (
                        <Button variant="outline" className="bg-green-500 hover:bg-green-600 text-white" onClick={reactivateSip} disabled={isSubmitting}>
                            {isSubmitting && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
                            Reactivate SIP
                        </Button>
                    )}
                </CardFooter>
            </form>
        </Form>
    </Card>
  );
}
