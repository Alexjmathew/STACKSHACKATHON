export const APP_NAME = "Stacks SIP Manager";
export const APP_ICON = "/icon.svg";

export const CONTRACT_ADDRESS = "ST3E6QWDGBHZ4AP29DACHG2QZKKKSGOATA8DNP62AS";
export const CONTRACT_NAME = "sip-manager-v1";
