import { clsx, type ClassValue } from "clsx"
import { twMerge } from "tailwind-merge"

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs))
}

export function toStx(microStx: number | string | bigint): string {
  const amount = typeof microStx === 'bigint' ? microStx : BigInt(microStx);
  return (Number(amount) / 1e6).toLocaleString(undefined, {
    minimumFractionDigits: 2,
    maximumFractionDigits: 6,
  });
}
