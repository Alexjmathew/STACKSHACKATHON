"use client";

import { useState, useEffect } from 'react';
import { userSession } from '@/lib/stacks';
import { APP_NAME, APP_ICON } from '@/lib/constants';
import WalletConnect from '@/components/wallet-connect';
import SipManager from '@/components/sip-manager';
import { Logo } from '@/components/logo';

export default function Home() {
  const [iconUrl, setIconUrl] = useState('');

  useEffect(() => {
    if (typeof window !== 'undefined') {
      setIconUrl(`${window.location.origin}${APP_ICON}`);
    }
  }, []);

  if (!iconUrl) {
    return null; 
  }

  return (
    <div className="flex min-h-screen w-full flex-col">
      <header className="sticky top-0 z-10 flex h-16 items-center gap-4 border-b bg-background/80 backdrop-blur-sm px-4 md:px-6">
        <nav className="hidden flex-col gap-6 text-lg font-medium md:flex md:flex-row md:items-center md:gap-5 md:text-sm lg:gap-6">
          <a
            href="#"
            className="flex items-center gap-2 text-lg font-semibold md:text-base"
          >
            <Logo />
            <span className="sr-only">{APP_NAME}</span>
          </a>
          <h1 className="text-xl font-bold">{APP_NAME}</h1>
        </nav>
        <div className="flex w-full items-center gap-4 md:ml-auto md:gap-2 lg:gap-4">
          <div className="ml-auto flex-1 sm:flex-initial">
            <WalletConnect />
          </div>
        </div>
      </header>
      <main className="flex flex-1 flex-col gap-4 p-4 md:gap-8 md:p-8">
        <div className="flex items-center">
          <h1 className="text-lg font-semibold md:text-2xl">My SIP Dashboard</h1>
        </div>
        <SipManager />
      </main>
    </div>
  );
}
